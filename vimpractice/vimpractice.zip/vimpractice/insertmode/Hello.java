/**
 * Hello.java
 *
 * A very sophisticated program that allows me to say hello to whoever I would like.
 *
 * @author Chris Wolf
 * @version 1.0.0 (January 19, 2019)
 *
 * crwolf3@catamount.wcu.edu
 */

public class Hello {
    public static void main(String[] args) {
        // TODO: Change to other students' names
        System.out.println("Hello Chris!");
    }
}
